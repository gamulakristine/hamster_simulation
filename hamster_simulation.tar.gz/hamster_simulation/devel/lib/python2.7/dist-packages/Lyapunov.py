import numpy as np
import scipy.linalg as sl


def solveLyapunov(xdim, kp, kd):

    A = np.bmat([[np.zeros((2, 2), dtype=np.float32), np.eye(2, dtype=np.float32)], [-kp * np.eye(2, dtype=np.float32), -kd * np.eye(2, dtype=np.float32)]])

    Q = np.eye(xdim, dtype=np.float32)

    try:
        P = sl.solve_continuous_are(A, np.zeros(
            (xdim, xdim), dtype=np.float32), Q, np.eye(xdim, dtype=np.float32))
    except:
        return 0

    # print(P)

    P = P.flatten().tolist()

    with open("./lyapunov.txt", 'w') as f:

        for p in P[:-1]:
            f.write(str(p) + "\n")

        f.write(str(P[-1]))
        f.close()

    return 1

# solveLyapunov(4, 1, 1)

