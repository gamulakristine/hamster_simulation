
"use strict";

let my_msg = require('./my_msg.js');

module.exports = {
  my_msg: my_msg,
};
