#ifndef PDCONTROLLER_H
#define PDCONTROLLER_H

#include <osqp/osqp.h>
#include <algorithm>
#include <eigen3/Eigen/Dense>

class PDcontroller
{
  // Kp is the proportional gain
  float Kp = 0;

  // Kd is the derivative gain
  float Kd = 0;

  // Time-step
  float dt = 0;

  Eigen::MatrixXf K;

public:
  PDcontroller(int xdim, int udim, float Kp, float Kd, float dt);

  Eigen::MatrixXf get_mu_pd(Eigen::MatrixXf error);
};

#endif