#include <OsqpEigen/OsqpEigen.h>
#include <eigen3/Eigen/Dense>

class myQPSolver
{
  int n = 2, m = 2;

  // instantiate the solver
  OsqpEigen::Solver solver;

public:
  // Matrix P
  Eigen::SparseMatrix<double> hessian;

  // Matrix q
  Eigen::VectorXd gradient;

  // Matrix A
  Eigen::SparseMatrix<double> linearMatrix;

  // Matrix l and u
  Eigen::VectorXd lowerBound;
  Eigen::VectorXd upperBound;

  myQPSolver();

  Eigen::VectorXd solve();

  ~myQPSolver();
};