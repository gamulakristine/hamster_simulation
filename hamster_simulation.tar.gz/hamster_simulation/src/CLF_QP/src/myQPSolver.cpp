#include "myQPSolver.hpp"

myQPSolver::myQPSolver()
{
  solver.settings()->setVerbosity(0);
  solver.settings()->setWarmStart(true);

  solver.data()->setNumberOfVariables(n);
  solver.data()->setNumberOfConstraints(m);

  // Matrix P
  hessian.resize(2, 2);
  hessian.insert(0, 0) = 1;
  hessian.insert(1, 1) = 1;
  solver.data()->setHessianMatrix(hessian);

  // Matrix q
  gradient.resize(2, 1);
  gradient << 0, 0;
  solver.data()->setGradient(gradient);

  // Matrix A
  linearMatrix.resize(2, 2);
  linearMatrix.insert(0, 0) = 1;
  linearMatrix.insert(1, 1) = 1;
  solver.data()->setLinearConstraintsMatrix(linearMatrix);

  // Matrix l and u
  lowerBound.resize(2, 1);
  lowerBound << -OsqpEigen::INFTY, -OsqpEigen::INFTY;
  solver.data()->setLowerBound(lowerBound);

  upperBound.resize(2, 1);
  upperBound << OsqpEigen::INFTY, OsqpEigen::INFTY;
  solver.data()->setUpperBound(upperBound);

  solver.initSolver();
}

Eigen::VectorXd myQPSolver::solve()
{
  solver.updateGradient(gradient);

  solver.solve();

  return solver.getSolution();
}

myQPSolver::~myQPSolver()
{
  solver.data()->~Data();
}