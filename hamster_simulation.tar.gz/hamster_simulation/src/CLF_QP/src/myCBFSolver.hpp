#include <OsqpEigen/OsqpEigen.h>
#include <eigen3/Eigen/Dense>

class myCBFSolver
{
  int n = 3, m = 3;

  // instantiate the solver
  OsqpEigen::Solver solver;

public:
  // Matrix P
  Eigen::SparseMatrix<double> hessian;

  // Matrix q
  Eigen::VectorXd gradient;

  // Matrix A
  Eigen::SparseMatrix<double> linearMatrix;

  // Matrix l and u
  Eigen::VectorXd lowerBound;
  Eigen::VectorXd upperBound;

  myCBFSolver();

  Eigen::VectorXd solve();

  ~myCBFSolver();
};