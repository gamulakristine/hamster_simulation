#include "myCBFSolver.hpp"

myCBFSolver::myCBFSolver()
{
  solver.settings()->setVerbosity(0);
  solver.settings()->setWarmStart(true);

  solver.data()->setNumberOfVariables(n);
  solver.data()->setNumberOfConstraints(m);

  // Matrix P
  hessian.resize(3, 3);
  hessian.insert(0, 0) = 1;
  hessian.insert(1, 1) = 1;
  hessian.insert(2, 2) = 100;
  solver.data()->setHessianMatrix(hessian);

  // Matrix q
  gradient.resize(3, 1);
  gradient << 0, 0, 0;
  solver.data()->setGradient(gradient);

  // Matrix A
  linearMatrix.resize(3, 3);
  linearMatrix.insert(0, 0) = 1;
  linearMatrix.insert(0, 1) = 1;
  linearMatrix.insert(2, 0) = 1;
  linearMatrix.insert(2, 1) = 1;
  solver.data()->setLinearConstraintsMatrix(linearMatrix);

  // Matrix l and u
  lowerBound.resize(3, 1);
  lowerBound << -OsqpEigen::INFTY, -OsqpEigen::INFTY, -OsqpEigen::INFTY;
  solver.data()->setLowerBound(lowerBound);

  upperBound.resize(3, 1);
  upperBound << OsqpEigen::INFTY, OsqpEigen::INFTY, OsqpEigen::INFTY;
  solver.data()->setUpperBound(upperBound);

  solver.initSolver();
}

Eigen::VectorXd myCBFSolver::solve()
{
  solver.updateLinearConstraintsMatrix(linearMatrix);

  solver.updateGradient(gradient);

  solver.updateLowerBound(lowerBound);

  solver.updateUpperBound(upperBound);

  solver.solve();

  return solver.getSolution();
}

myCBFSolver::~myCBFSolver()
{
  solver.data()->~Data();
}