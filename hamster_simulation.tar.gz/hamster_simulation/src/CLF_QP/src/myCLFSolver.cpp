#include "myCLFSolver.hpp"

myCLFSolver::myCLFSolver()
{
  solver.settings()->setVerbosity(0);
  solver.settings()->setWarmStart(true);

  solver.data()->setNumberOfVariables(n);
  solver.data()->setNumberOfConstraints(m);

  // Matrix P
  hessian.resize(2, 2);
  hessian.insert(0, 0) = 1;
  hessian.insert(1, 1) = 1;
  solver.data()->setHessianMatrix(hessian);

  // Matrix q
  gradient.resize(2, 1);
  gradient << 0, 0;
  solver.data()->setGradient(gradient);

  // Matrix A
  linearMatrix.resize(2, 2);
  linearMatrix.insert(0, 0) = 1;
  linearMatrix.insert(0, 1) = 1;
  solver.data()->setLinearConstraintsMatrix(linearMatrix);

  // Matrix l and u
  lowerBound.resize(2, 1);
  lowerBound << -OsqpEigen::INFTY, -OsqpEigen::INFTY;
  solver.data()->setLowerBound(lowerBound);

  upperBound.resize(2, 1);
  upperBound << OsqpEigen::INFTY, OsqpEigen::INFTY;
  solver.data()->setUpperBound(upperBound);

  solver.initSolver();
}

Eigen::VectorXd myCLFSolver::solve()
{
  solver.updateLinearConstraintsMatrix(linearMatrix);

  solver.updateGradient(gradient);

  solver.updateUpperBound(upperBound);

  solver.solve();

  return solver.getSolution();
}

myCLFSolver::~myCLFSolver()
{
  solver.data()->~Data();
}