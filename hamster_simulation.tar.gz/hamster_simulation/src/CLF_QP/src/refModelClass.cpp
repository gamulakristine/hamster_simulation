#include "refModelClass.hpp"

refModelClass::refModelClass(int xdim, int udim, float radius, float v, float next_step, float dt)
{
  refModelClass::xdim = xdim;
  refModelClass::udim = udim;
  refModelClass::radius = radius;

  refModelClass::v = v;
  refModelClass::dt = dt;
  refModelClass::next_step = next_step;

  x_rm.resize(xdim, 1);
}

Eigen::MatrixXf refModelClass::get_x_rm(Eigen::MatrixXf my_pos, Eigen::MatrixXf center)
{
  float theta = atan2f(my_pos(1, 0) - center(1, 0), my_pos(0, 0) - center(0, 0)) + next_step;

  x_rm(0, 0) = center(0, 0) + radius * cosf(theta);
  x_rm(1, 0) = center(1, 0) + radius * sinf(theta);

  x_rm(2, 0) = getGradient(my_pos, x_rm);
  x_rm(3, 0) = v;

  x_rm.cast<c_float>();
  return x_rm;
}

Eigen::MatrixXf refModelClass::get_mu_rm(Eigen::MatrixXf z_rm)
{
  Eigen::MatrixXf u_rm(udim, 1);

  u_rm(0, 0) = z_rm(2, 0) / dt;
  u_rm(1, 0) = z_rm(3, 0) / dt;

  // Clip error
  // u_rm(0, 0) = std::min(std::max(u_rm(0, 0), -1.f), 1.f);
  // u_rm(1, 0) = std::min(std::max(u_rm(1, 0), -1.f), 1.f);

  u_rm.cast<c_float>();
  return u_rm;
}

float refModelClass::getGradient(Eigen::MatrixXf p1, Eigen::MatrixXf p2)
{
  /**
 * Computes the slope/gradient of the line passing through 2 points
 *
 * @param p1 Point on one end of the line
 * @param p2 Point on another end of the line
 * @return Slope of line through p1 and p2
*/

  float grad = 0.0;

  // direction vector p1 to p2
  float deltaX = p2(0, 0) - p1(0, 0);
  float deltaY = p2(1, 0) - p1(1, 0);

  if (deltaX != 0)
  {
    // 1st quadrant is default
    grad = atan(deltaY / deltaX);

    // deltaY zero case and deltaX < 0
    if (deltaY == 0 && deltaX < 0)
      grad = M_PI;
    // 2nd quadrant
    else if (deltaY > 0 && deltaX < 0)
      grad = M_PI + grad;
    // 3rd quadrant
    else if (deltaY < 0 && deltaX < 0)
      grad = -M_PI + grad;
    // 4th quadrant
    else if (deltaY < 0 && deltaX > 0)
      grad = grad;
  }
  else
  {
    // deltaX zero case
    if (deltaY > 0)
      grad = M_PI / 2;
    else if (deltaY < 0)
      grad = -M_PI / 2;
    else
      grad = 0.0;
  }

  return grad;
}