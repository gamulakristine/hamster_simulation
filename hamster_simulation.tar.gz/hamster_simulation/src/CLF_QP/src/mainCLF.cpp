/**
 *  HAMSTER ROS Adaptive Control
 *  mainCLF.cpp
 *  Purpose: To move the Hamster vehicle in a circle for a given radius and velocity using CLF controller
 *
 *  @author Aniketh Manjunath
 *  @version 3.0 - 10 Apr 2020
 */

#include <ackermann_msgs/AckermannDriveStamped.h>
#include <pybind11/embed.h>
#include <tf/transform_listener.h>
#include <cmath>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/QR>
#include <fstream>
#include "PDcontrollerClass.hpp"
#include "dynamicsClass.hpp"
#include "myCLFSolver.hpp"
#include "nav_msgs/Odometry.h"
#include "refModelClass.hpp"
#include "ros/ros.h"

namespace py = pybind11;

// Length of Hamster Robot
#define L 0.2

// Global variable declaration
Eigen::MatrixXf x;

void odomCallback(const nav_msgs::Odometry::ConstPtr &msg)
{
  /**
 * Callback function of Subscriber (agent1/odom)
 *
 * @param msg Pointer to Odometry message
 */

  x(0, 0) = msg->pose.pose.position.x;
  x(1, 0) = msg->pose.pose.position.y;
  x(2, 0) = tf::getYaw(msg->pose.pose.orientation);
  x(3, 0) = sqrtf(powf(msg->twist.twist.linear.x, 2) + powf(msg->twist.twist.linear.y, 2));
}

int main(int argc, char **argv)
{
  int xdim = 4;
  int udim = 2;

  float radius = 1.f;

  float dt = 0.1;
  float kp = 1.;
  float kd = 1.;
  float v = 0.5;
  float step = 10 * M_PI / 180;

  py::initialize_interpreter();
  {  // scoped
    py::module lyapunov = py::module::import("Lyapunov");
    py::object result = lyapunov.attr("solveLyapunov")(xdim, kp, kd);

    if (result.cast<int>())
      ROS_INFO("Python Lyapunov Success");
    else
    {
      ROS_INFO("Python Lyapunov Failed");
      return false;
    }
  }  // <-- OK, hello is cleaned up properly
  py::finalize_interpreter();

  Eigen::MatrixXf err;
  Eigen::MatrixXf mu;
  Eigen::MatrixXf g_inv;
  Eigen::MatrixXf LgV;
  Eigen::MatrixXf LfV;
  Eigen::MatrixXf F;
  Eigen::MatrixXf G;
  Eigen::MatrixXf P;
  Eigen::MatrixXf U;

  // Lyapunov Equation Solution
  P.resize(xdim, xdim);
  int i = 0, j = 0;
  float p = -1;
  std::ifstream infile("./lyapunov.txt");

  while (infile >> p)
  {
    P(i, j) = p;
    j += 1;

    if (j == xdim)
    {
      j = 0;
      i += 1;
    }
  }

  F.resize(xdim, xdim);
  F << 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0;

  Eigen::MatrixXf Ft = F.transpose();
  Eigen::MatrixXf Q(4, 4);
  Q << 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1;

  G.resize(xdim, udim);
  G << 0, 0, 0, 0, 1, 0, 0, 1;

  Eigen::MatrixXf u;
  Eigen::MatrixXf z;

  x.resize(xdim, 1);
  u.resize(udim, 1);
  z.resize(xdim, 1);

  ros::init(argc, argv, "adaptive_controller");
  ros::NodeHandle n;
  ros::Rate r = 100;

  ackermann_msgs::AckermannDriveStamped steering;

  // Subscribe to Odometer readings
  ros::Subscriber odom_sub = n.subscribe("/agent1/odom", 10, odomCallback);

  // Publish to ackermann_cmd for robot motion control
  ros::Publisher ackr_pub = n.advertise<ackermann_msgs::AckermannDriveStamped>("/agent1/ackermann_cmd", 10);

  // PD control
  PDcontroller PD(xdim, udim, kp, kd, dt);

  // Reference Model i.e. Path Planner
  refModelClass RM(xdim, udim, radius, v, step, dt);

  // Reference model params
  Eigen::MatrixXf x_rm(xdim, 1);
  Eigen::MatrixXf z_pm(xdim, 1);
  Eigen::MatrixXf z_rm(xdim, 1);

  Eigen::MatrixXf mu_rm(udim, 1);
  Eigen::MatrixXf mu_pd(udim, 1);

  // Origin
  Eigen::MatrixXf center(2, 1);
  center(0, 0) = center(1, 0) = 0;

  // Dynamics Class for ref model and cur model
  dynamicsClass rm(xdim, udim);
  dynamicsClass cm(xdim, udim);

  myCLFSolver osqp;
  Eigen::VectorXd QPSolution;

  ros::spinOnce();

  // Initialize previous reference model
  x_rm = RM.get_x_rm(x, center);
  z_pm = rm.getZfromX();

  bool init = true;

  while (!ros::isShuttingDown())
  {
    rm.initX(x_rm);
    cm.initX(x);

    z_rm = rm.getZfromX();
    z = cm.getZfromX();

    err = z - z_rm;
    mu_pd = PD.get_mu_pd(err);
    mu_rm = RM.get_mu_rm(z_rm - z_pm);

    z_pm = z_rm;

    g_inv = cm.getG().inverse();

    mu = mu_pd + mu_rm;

    // // Check for NaN
    if (isnanf(g_inv(0, 0)))
      g_inv(0, 0) = 0.000001;
    if (isnanf(g_inv(0, 1)))
      g_inv(0, 1) = 0.000001;
    if (isnanf(g_inv(1, 0)))
      g_inv(1, 0) = 0.000001;
    if (isnanf(g_inv(1, 1)))
      g_inv(1, 1) = 0.000001;

    LfV = (err.transpose() * (Ft * P + P * F)) * err;
    LgV = 2 * err.transpose() * P * G;
    U = -LfV - err.transpose() * Q * err;

    // Update Linear Constraint Matrix
    osqp.linearMatrix.setZero();
    osqp.linearMatrix.insert(0, 0) = LgV.data()[0];
    osqp.linearMatrix.insert(0, 1) = LgV.data()[1];

    // Update Gradient Vector
    osqp.gradient.data()[0] = -mu.data()[0];
    osqp.gradient.data()[1] = -mu.data()[1];

    // Update Upper Bound
    osqp.upperBound.data()[0] = U.data()[0];

    // Solve QP problem
    QPSolution = osqp.solve();

    ROS_INFO("PD: %.2f, %.2f", mu(0, 0), mu(1, 0));

    mu.data()[0] = QPSolution.data()[0];
    mu.data()[1] = QPSolution.data()[1];

    ROS_INFO("CLF: %.2f, %.2f", mu(0, 0), mu(1, 0));

    u = g_inv * (mu - cm.getF());

    u(0, 0) = atanf(u(0, 0) * L);

    // Clip control as per robot specs
    u(0, 0) = std::min(std::max(u(0, 0), -1.f), 1.f);
    u(1, 0) = std::min(std::max(u(1, 0), 0.1f), 1.2f);

    steering.drive.steering_angle = u(0, 0);
    steering.drive.speed = u(1, 0);

    // ROS_INFO("UM: %.2f, %.2f", u(0, 0), u(1, 0));
    ROS_INFO("SM: %.2f, %.2f\n", steering.drive.steering_angle, steering.drive.speed);

    ros::spinOnce();

    ackr_pub.publish(steering);
    r.sleep();

    x_rm = RM.get_x_rm(x, center);
  }
}