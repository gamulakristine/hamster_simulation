/**
 *  HAMSTER ROS Matrix Class
 *  matrixClass.cpp
 *  Purpose: Matrix class for matrix operations like inverse
 *
 *  @author Aniketh Manjunath
 *  @version 1.0 1{1/01/20
 */

#include <Dense>
#include <iostream>

using namespace std;
using namespace Eigen;

class matrixClass
{
  MatrixXf m;

  matrixClass(int rows, int cols, float **g)
  {
    m.resize(rows, cols);
    for (int i = 0; i < rows; i++)
    {
      for (int j = 0; j < cols; j++)
      {
        m(i, j) = g[i][j];
      }
    }
  }

  matrixClass(MatrixXf n)
  {
    m = n;
  }

public:
  float **getArray()
  {
    float **a;

    a = new float *[m.rows];

    for (int i = 0; i < m.rows; i++)
    {
      a[i] = new float[m.cols];
      for (int j = 0; j < m.cols; j++)
      {
        a[i][j] = m(i, j);
      }
    }

    return a;
  }

  matrixClass getInverse()
  {
    return matrixClass(m.inverse());
  }

  void print()
  {
    cout << m << endl;
  }
};