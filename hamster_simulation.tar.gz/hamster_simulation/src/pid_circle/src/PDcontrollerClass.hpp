#ifndef PDCONTROLLER_H
#define PDCONTROLLER_H

#include <Dense>

class PDcontroller
{
  // Kp is the proportional gain
  float Kp = 0;

  // Kd is the derivative gain
  float Kd = 0;

  // Time-step
  float dt = 0;

  // Previous error
  float pre_err = 0;

  // Current error
  float cur_err = 0;

public:
  PDcontroller(float Kp = 0.5, float Kd = 0.05, float dt = 0.1);

  /**
     * Computes the weighted sum of control terms
     *
     * @param pre_err Previous error
     * @param cur_err Current error
     * @param dt Time Step
     * @return Weighted sum of errors
    */
  float compute_error();

  /**
     * Computes the target position - a point on the circle of radius r for the given center and angle theta
     *
     * @param theta The angle subtended by the point at the circle's center.
     * @param radius The radius of the circle
     * @param center The center point of the circle
     * @return Point on the circle
    */
  Eigen::MatrixXf desired_pos(float theta, float radius, Eigen::MatrixXf center);

  /**
    * Computes the slope/gradient of the line passing through 2 points
    *
    * @param p1 Point on one end of the line
    * @param p2 Point on another end of the line
    * @return Slope of line through p1 and p2
   */
  float getGradient(Eigen::MatrixXf p1, Eigen::MatrixXf p2);
};

#endif