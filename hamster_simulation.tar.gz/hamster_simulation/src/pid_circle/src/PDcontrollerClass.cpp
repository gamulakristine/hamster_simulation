#include "PDcontrollerClass.hpp"

PDcontroller::PDcontroller(float Kp = 0.5, float Kd = 0.05, float dt = 0.1)
{
  PDcontroller::Kp = Kp;
  PDcontroller::Kd = Kd;
  PDcontroller::dt = dt;
}

float PDcontroller::compute_error()
{
  return (Kp * cur_err) + (Kd * (cur_err - pre_err) / dt);
}

Eigen::MatrixXf PDcontroller::desired_pos(float theta, float radius, Eigen::MatrixXf center)
{
  Eigen::MatrixXf goal(2, 1);

  goal(0, 0) = center(0, 0) + radius * cosf(theta);
  goal(1, 0) = center(1, 0) + radius * sinf(theta);

  return goal;
}

float PDcontroller::getGradient(Eigen::MatrixXf p1, Eigen::MatrixXf p2)
{
  float grad = 0.0;

  // direction vector p1 to p2
  float deltaX = p2(0, 0) - p1(0, 0);
  float deltaY = p2(1, 0) - p1(1, 0);

  if (deltaX != 0)
  {
    // 1st quadrant is default
    grad = atanf(deltaY / deltaX);

    // deltaY zero case and deltaX < 0
    if (deltaY == 0 && deltaX < 0)
      grad = M_PI;
    // 2nd quadrant
    else if (deltaY > 0 && deltaX < 0)
      grad = M_PI + grad;
    // 3rd quadrant
    else if (deltaY < 0 && deltaX < 0)
      grad = -M_PI + grad;
    // 4th quadrant
    else if (deltaY < 0 && deltaX > 0)
      grad = grad;
  }
  else
  {
    // deltaX zero case
    if (deltaY > 0)
      grad = M_PI / 2;
    else if (deltaY < 0)
      grad = -M_PI / 2;
    else
      grad = 0.0;
  }

  return grad;
}