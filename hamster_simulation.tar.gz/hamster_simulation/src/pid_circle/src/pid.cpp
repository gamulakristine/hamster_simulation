/**
 *  HAMSTER ROS Test
 *  PID.cpp
 *  Purpose: To move the Hamster vehicle in a circle for a given radius and velocity using simple PD controller
 *
 *  @author Aniketh Manjunath
 *  @version 1.0 21/11/19
 */

#include <ackermann_msgs/AckermannDriveStamped.h>
#include <pid_circle/my_msg.h>
#include <tf/transform_listener.h>
#include <cmath>
#include "nav_msgs/Odometry.h"
#include "ros/ros.h"

// Kp is the proportional gain
double Kp = .5;

// Kd is the derivative gain
double Kd = .05;

// Global variable declaration
double yaw;
geometry_msgs::Point cur_pos;

// Custom message for plotting
pid_circle::my_msg new_msg;

double error_from_pid(double pre_err, double cur_err, double dt = 0.1)
{
  /**
 * Computes the weighted sum of control terms
 *
 * @param pre_err Previous error
 * @param cur_err Current error
 * @param dt Time Step
 * @return Weighted sum of errors
*/

  return (Kp * cur_err) + (Kd * (cur_err - pre_err) / dt);
}

void odomCallback(const nav_msgs::Odometry::ConstPtr &msg)
{
  /**
 * Callback function of Subscriber (agent1/odom)
 *
 * @param msg Pointer to Odometry message
 */

  yaw = tf::getYaw(msg->pose.pose.orientation);
  cur_pos = msg->pose.pose.position;

  new_msg.x = msg->pose.pose.position.x;
  new_msg.y = msg->pose.pose.position.y;
  new_msg.velocity = msg->twist.twist.linear.x;
}

geometry_msgs::Point desired_pos(double theta, double radius, geometry_msgs::Point center)
{
  /**
 * Computes the target position - a point on the circle of radius r for the given center and angle theta
 *
 * @param theta The angle subtended by the point at the circle's center.
 * @param radius The radius of the circle
 * @param center The center point of the circle
 * @return Point on the circle
*/

  geometry_msgs::Point goal;

  goal.x = center.x + radius * cos(theta);
  goal.y = center.y + radius * sin(theta);

  return goal;
}

double getGradient(geometry_msgs::Point p1, geometry_msgs::Point p2)
{
  /**
 * Computes the slope/gradient of the line passing through 2 points
 *
 * @param p1 Point on one end of the line
 * @param p2 Point on another end of the line
 * @return Slope of line through p1 and p2
*/

  double grad = 0.0;

  // direction vector p1 to p2
  double deltaX = p2.x - p1.x;
  double deltaY = p2.y - p1.y;

  if (deltaX != 0)
  {
    // 1st quadrant is default
    grad = atan(deltaY / deltaX);

    // deltaY zero case and deltaX < 0
    if (deltaY == 0 && deltaX < 0)
      grad = M_PI;
    // 2nd quadrant
    else if (deltaY > 0 && deltaX < 0)
      grad = M_PI + grad;
    // 3rd quadrant
    else if (deltaY < 0 && deltaX < 0)
      grad = -M_PI + grad;
    // 4th quadrant
    else if (deltaY < 0 && deltaX > 0)
      grad = grad;
  }
  else
  {
    // deltaX zero case
    if (deltaY > 0)
      grad = M_PI / 2;
    else if (deltaY < 0)
      grad = -M_PI / 2;
    else
      grad = 0.0;
  }

  return grad;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "pid_controller");
  ros::NodeHandle n;

  ackermann_msgs::AckermannDriveStamped steering;

  // Subscribe to Odometer readings
  ros::Subscriber sub = n.subscribe("/agent1/odom", 10, odomCallback);

  // Publish to ackermann_cmd for robot motion control
  ros::Publisher ackr_pub = n.advertise<ackermann_msgs::AckermannDriveStamped>("/agent1/ackermann_cmd", 10);
  ros::Publisher msg_pub = n.advertise<pid_circle::my_msg>("/agent1/my_msg", 10);

  ros::Rate r = 30;

  // Desired radius of circular path
  int radius = 1;

  // Linear velocity of the robot
  float speed = 0.5;

  // Desired angle between current_position and target_position
  double targetAngle = 0;

  // Eucledian distance between current_position and target_position
  double distError = 0;

  // Error between robot orientation and desired orientation at time t
  double curAngleError = 0;

  // Error between robot orientation and desired orientation at time t - 1
  double preAngleError = 0;

  // Next target position in steps of 15 degrees
  double next_step = 15 * M_PI / 180;

  // Error computed by PD controller
  double err = 0;

  // Point on the circular path
  geometry_msgs::Point target_pos;

  // Center of the circular path
  geometry_msgs::Point center_pos;
  center_pos.x = 0;
  center_pos.y = 0;

  steering.drive.speed = speed;

  while (!ros::isShuttingDown())
  {
    target_pos = desired_pos(atan2(cur_pos.y - center_pos.y, cur_pos.x - center_pos.x) + next_step, radius, center_pos);

    distError = sqrt(pow(target_pos.x - cur_pos.x, 2) + pow(target_pos.y - cur_pos.y, 2));

    targetAngle = getGradient(cur_pos, target_pos);

    curAngleError = targetAngle - yaw;

    // Checking bounds of angle error
    curAngleError = (curAngleError) > M_PI ? curAngleError - 2 * M_PI :
                                             (curAngleError < -M_PI) ? curAngleError + 2 * M_PI : curAngleError;

    err = error_from_pid(preAngleError, curAngleError);

    preAngleError = curAngleError;

    // ROS_INFO("Error(D, A): (%f, %f)", distError, err);

    steering.drive.steering_angle = err;

    new_msg.steer_angle = steering.drive.steering_angle;
    new_msg.steer_velocity = steering.drive.steering_angle_velocity;
    new_msg.motor_speed = steering.drive.speed;

    ros::spinOnce();

    ackr_pub.publish(steering);
    msg_pub.publish(new_msg);
    r.sleep();
  }
}