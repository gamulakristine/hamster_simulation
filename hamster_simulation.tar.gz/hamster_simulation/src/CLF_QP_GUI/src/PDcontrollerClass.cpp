#include "../include/PDcontrollerClass.hpp"

PDcontroller::PDcontroller(int xdim, int udim, float Kp = 0.5, float Kd = 0.05, float dt = 0.1)
{
  PDcontroller::Kp = Kp;
  PDcontroller::Kd = Kd;
  PDcontroller::dt = dt;

  K.resize(udim, xdim);

  for (int i = 0; i < xdim / 2; i++)
  {
    if (i % 2 == 0)
    {
      K(0, i) = -Kp;
      K(1, i) = 0;
    }
    else
    {
      K(0, i) = 0;
      K(1, i) = -Kp;
    }
  }

  for (int i = xdim / 2; i < xdim; i++)
  {
    if (i % 2 == 0)
    {
      K(0, i) = -Kd;
      K(1, i) = 0;
    }
    else
    {
      K(0, i) = 0;
      K(1, i) = -Kd;
    }
  }
}

Eigen::MatrixXf PDcontroller::get_mu_pd(Eigen::MatrixXf error)
{
  Eigen::MatrixXf mu_pd = K * error;

  // Clip error
  // mu_pd(0, 0) = std::min(std::max(mu_pd(0, 0), -1.f), 1.f);
  // mu_pd(1, 0) = std::min(std::max(mu_pd(1, 0), -1.f), 1.f);

  return mu_pd;
}

void PDcontroller::set_K(float Kp, float Kd)
{
  PDcontroller::Kp = Kp;
  PDcontroller::Kd = Kd;
}