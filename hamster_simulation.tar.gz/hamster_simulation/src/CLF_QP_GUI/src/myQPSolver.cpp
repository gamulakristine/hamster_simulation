#include "../include/myQPSolver.hpp"

myQPSolver::myQPSolver()
{
  // Populate data
  if (data)
  {
    data->n = n;
    data->m = m;
    data->P = csc_matrix(data->n, data->n, P_nnz, P_x, P_i, P_p);
    data->q = q;
    data->A = csc_matrix(data->n, data->n, A_nnz, A_x, A_i, A_p);
    data->l = l;
    data->u = u;
  }

  // Define solver settings as default
  if (settings)
  {
    osqp_set_default_settings(settings);
    settings->alpha = 1.0;  // Change alpha parameter
    settings->verbose = 0;
  }

  // Setup workspace
  exitflag = osqp_setup(&work, data, settings);
  // ROS_INFO("QP Exit_Code: %d\n", exitflag);

  // Solve Problem
  osqp_solve(work);
}

void myQPSolver::solve(float* b)
{
  q[0] = -b[0];
  q[1] = -b[1];

  osqp_update_lin_cost(work, q);

  // Solve Problem
  osqp_solve(work);

  ROS_INFO("QP Solved: %d", work->info->status_val);
  ROS_INFO("PD: %.2f, %.2f", b[0], b[1]);
  ROS_INFO("QP: %.2f, %.2f", work->solution->x[0], work->solution->x[1]);

  b[0] = work->solution->x[0];
  b[1] = work->solution->x[1];

  return;
}

myQPSolver::~myQPSolver()
{
  // Cleanup
  if (data)
  {
    if (data->A)
      c_free(data->A);
    if (data->P)
      c_free(data->P);
    c_free(data);
  }
  if (settings)
    c_free(settings);
}