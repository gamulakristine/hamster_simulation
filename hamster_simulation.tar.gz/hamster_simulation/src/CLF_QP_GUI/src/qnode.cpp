/**
 * @file /src/qnode.cpp
 *
 * @brief Ros communication central!
 *
 * @date February 2011
 **/

/*****************************************************************************
** Includes
*****************************************************************************/

#include <pybind11/embed.h>
#include <ros/network.h>
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <sstream>
#include <string>
#include "../include/CLF_QP_GUI/qnode.hpp"

/*****************************************************************************
** Namespaces
*****************************************************************************/
namespace CLF_QP_GUI
{
namespace py = pybind11;

/*****************************************************************************
** Implementation
*****************************************************************************/

static void odomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
  /**
 * Callback function of Subscriber (agent1/odom)
 *
 * @param msg Pointer to Odometry message
 */

  x(0, 0) = msg->pose.pose.position.x;
  x(1, 0) = msg->pose.pose.position.y;
  x(2, 0) = tf::getYaw(msg->pose.pose.orientation);
  x(3, 0) = sqrtf(powf(msg->twist.twist.linear.x, 2) + powf(msg->twist.twist.linear.y, 2));
}

QNode::QNode(int argc, char** argv) : init_argc(argc), init_argv(argv)
{
}

QNode::~QNode()
{
  if (ros::isStarted())
  {
    ros::shutdown();  // explicitly needed since we use ros::start();
    ros::waitForShutdown();
  }
  wait();
}

bool QNode::init(bool var)
{
  ros::init(init_argc, init_argv, "CLF_QP_GUI");
  if (!ros::master::check())
  {
    return false;
  }

  ros::NodeHandle n;
  ros::start();  // explicitly needed since our nodehandle is going out of scope.
  odom_sub = n.subscribe("/agent1/odom", 10, odomCallback);
  ackr_pub = n.advertise<ackermann_msgs::AckermannDriveStamped>("/agent1/ackermann_cmd", 10);

  steering.drive.steering_angle = 0;
  steering.drive.speed = 0;

  x.resize(xdim, 1);
  u.resize(udim, 1);
  z.resize(xdim, 1);

  center.resize(2, 1);
  center(0, 0) = center(1, 0) = 0;

  PD_control = var;

  start();

  py::initialize_interpreter();
  {  // scoped
    py::module lyapunov = py::module::import("Lyapunov");
    py::object result = lyapunov.attr("solveLyapunov")(xdim, kp, kd);

    if (result.cast<int>())
      ROS_INFO("Python Lyapunov Success");
    else
    {
      ROS_INFO("Python Lyapunov Failed");
      return false;
    }
  }  // <-- OK, hello is cleaned up properly
  py::finalize_interpreter();

  return true;
}

void QNode::run()
{
  // Reference model params
  Eigen::MatrixXf x_rm(xdim, 1);
  Eigen::MatrixXf z_pm(xdim, 1);
  Eigen::MatrixXf z_rm(xdim, 1);

  Eigen::MatrixXf mu_rm(udim, 1);
  Eigen::MatrixXf mu_pd(udim, 1);

  Eigen::MatrixXf err;
  Eigen::MatrixXf mu;
  Eigen::MatrixXf g_inv;
  Eigen::MatrixXf LgV;
  Eigen::MatrixXf LfV;
  Eigen::MatrixXf F;
  Eigen::MatrixXf G;
  Eigen::MatrixXf P;
  Eigen::MatrixXf U;

  // Lyapunov Equation Solution
  P.resize(xdim, xdim);
  int i = 0, j = 0;
  float p = -1;
  std::ifstream infile("./lyapunov.txt");

  while (infile >> p)
  {
    P(i, j) = p;
    j += 1;

    if (j == xdim)
    {
      j = 0;
      i += 1;
    }
  }

  F.resize(xdim, xdim);
  F << 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0;

  Eigen::MatrixXf Ft = F.transpose();
  Eigen::MatrixXf I(4, 4);
  I << 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1;

  G.resize(xdim, udim);
  G << 0, 0, 0, 0, 1, 0, 0, 1;

  // PD control
  PDcontroller PD(xdim, udim, kp, kd, dt);

  // Reference Model i.e. Path Planner
  refModelClass RM(xdim, udim, radius, v, step, dt);

  // Dynamics Class for ref model and cur model
  dynamicsClass rm(xdim, udim);
  dynamicsClass cm(xdim, udim);

  myQPSolver osqp;
  myCLFSolver clfqp;

  ros::Rate r = 50;
  ros::spinOnce();

  // Initialize previous reference model
  x_rm = RM.get_x_rm(x, center);
  z_pm = rm.getZfromX();

  while (ros::ok())
  {
    if (new_commit)
    {
      new_commit = false;

      // PD Model Params
      PD.set_K(kp, kd);

      // Ref Model Params
      RM.set_speed(v);
      RM.set_radius(radius);

      // Initialize previous reference model
      x_rm = RM.get_x_rm(x, center);
      z_pm = rm.getZfromX();
    }

    rm.initX(x_rm);
    cm.initX(x);

    z_rm = rm.getZfromX();
    z = cm.getZfromX();

    err = z - z_rm;
    mu_pd = PD.get_mu_pd(err);
    mu_rm = RM.get_mu_rm(z_rm - z_pm);

    z_pm = z_rm;

    g_inv = cm.getG().inverse();

    // Check for NaN
    if (isnanf(g_inv(0, 0)))
      g_inv(0, 0) = 0.000001;
    if (isnanf(g_inv(0, 1)))
      g_inv(0, 1) = 0.000001;
    if (isnanf(g_inv(1, 0)))
      g_inv(1, 0) = 0.000001;
    if (isnanf(g_inv(1, 1)))
      g_inv(1, 1) = 0.000001;

    mu = mu_pd + mu_rm;

    // QP controller
    if (!PD_control)
    {
      osqp.solve(mu.data());
    }
    // CLF controller
    else
    {
      LfV = (err.transpose() * (Ft * P + P * F)) * err;
      LgV = 2 * err.transpose() * P * G;
      U = -LfV - err.transpose() * I * err;
      // std::cout << LfV << ',' << LgV << ',' << U << std::endl;
      clfqp.solve(mu.data(), LgV.data(), U.data());
    }

    u = g_inv * (mu - cm.getF());

    u(0, 0) = atanf(u(0, 0) * L);

    // Clip control as per robot specs
    u(0, 0) = std::min(std::max(u(0, 0), -1.f), 1.f);
    u(1, 0) = std::min(std::max(u(1, 0), 0.1f), 1.2f);

    steering.drive.steering_angle = u(0, 0);
    steering.drive.speed = u(1, 0);

    // ROS_INFO("UM: %f, %f", u(0, 0), u(1, 0));
    // ROS_INFO("SM: %f, %f\n", steering.drive.steering_angle, steering.drive.speed);

    ros::spinOnce();

    ackr_pub.publish(steering);
    r.sleep();

    x_rm = RM.get_x_rm(x, center);
  }
}

}  // namespace CLF_QP_GUI