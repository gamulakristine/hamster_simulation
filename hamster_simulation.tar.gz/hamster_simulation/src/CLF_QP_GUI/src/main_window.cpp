/**
 * @file /src/main_window.cpp
 *
 * @brief Implementation for the qt gui.
 *
 * @date February 2011
 **/
/*****************************************************************************
** Includes
*****************************************************************************/

#include <QMessageBox>
#include <QtGui>
#include <iostream>
#include "../include/CLF_QP_GUI/main_window.hpp"

/*****************************************************************************
** Namespaces
*****************************************************************************/

namespace CLF_QP_GUI
{
using namespace Qt;

/*****************************************************************************
** Implementation [MainWindow]
*****************************************************************************/

MainWindow::MainWindow(int argc, char **argv, QWidget *parent) : QMainWindow(parent), qnode(argc, argv)
{
  ui.setupUi(this);  // Calling this incidentally connects all ui's triggers to on_...() callbacks in this class.

  ui.radioButtonPD->setChecked(true);

  // QObject::connect(&qnode, SIGNAL(on_pushButtonCommit_clicked()), this, SLOT(started()));
}

MainWindow::~MainWindow()
{
}

/*****************************************************************************
** Implementation [Slots]
*****************************************************************************/

/*
 * These triggers whenever the button is clicked, regardless of whether it
 * is already checked or not.
 */
void MainWindow::on_pushButtonCommit_clicked()
{
  if (!started)
  {
    started = true;

    qnode.radius = (float)ui.doubleSpinBoxRadius->value();
    qnode.kp = (float)ui.doubleSpinBoxKp->value();
    qnode.kd = (float)ui.doubleSpinBoxKd->value();
    qnode.v = (float)ui.doubleSpinBoxSpeed->value();

    if (!qnode.init(ui.radioButtonPD->isChecked()))
    {
      QMessageBox msgBox;
      msgBox.setText("Setup Failed. Check Code!");
      msgBox.exec();
      close();
    }
  }
  else
  {
    qnode.radius = (float)ui.doubleSpinBoxRadius->value();
    qnode.kp = (float)ui.doubleSpinBoxKp->value();
    qnode.kd = (float)ui.doubleSpinBoxKd->value();
    qnode.v = (float)ui.doubleSpinBoxSpeed->value();

    qnode.PD_control = ui.radioButtonPD->isChecked();

    qnode.new_commit = true;
  }
}

void MainWindow::on_pushButtonReset_clicked()
{
}

void MainWindow::on_pushButtonStop_clicked()
{
  QMainWindow::close();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
  QMainWindow::closeEvent(event);
}

}  // namespace CLF_QP_GUI
