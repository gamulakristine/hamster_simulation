#include "../include/dynamicsClass.hpp"

dynamicsClass::dynamicsClass(int xdim, int udim)
{
  dynamicsClass::xdim = xdim;
  dynamicsClass::udim = udim;

  x.resize(xdim, 1);
  u.resize(udim, 1);
  z.resize(xdim, 1);
}

void dynamicsClass::initX(Eigen::MatrixXf x)
{
  dynamicsClass::x = x;
}

void dynamicsClass::initU(Eigen::MatrixXf u)
{
  dynamicsClass::u = u;
}

void dynamicsClass::xToZ()
{
  z(0, 0) = x(0, 0);
  z(1, 0) = x(1, 0);
  z(2, 0) = x(3, 0) * cosf(x(2, 0));
  z(3, 0) = x(3, 0) * sinf(x(2, 0));
}

void dynamicsClass::zToX()
{
  x(0, 0) = z(0, 0);
  x(1, 0) = z(1, 0);
  x(2, 0) = atan2f(z(3, 0), z(2, 0));
  x(3, 0) = 1;
}

Eigen::MatrixXf dynamicsClass::getF()
{
  // Eigen::MatrixXf f(xdim, 1);

  // f(2, 0) = f(3, 0) = 0;
  // f(0, 0) = z(3, 0) * cosf(z(2, 0));
  // f(1, 0) = z(3, 0) * sinf(z(2, 0));

  Eigen::MatrixXf f(udim, 1);

  f(0, 0) = 0;
  f(1, 0) = 0;

  return f;
}

Eigen::MatrixXf dynamicsClass::getG()
{
  // Eigen::MatrixXf g(xdim, udim);

  // g(0, 0) = g(0, 1) = 0;
  // g(1, 0) = g(1, 1) = 0;
  // g(2, 1) = g(3, 0) = 0;

  // g(2, 0) = z(3, 0);  // * cosf(x(2, 0));
  // g(3, 1) = 1;        // x(3, 0) * sinf(x(2, 0));

  Eigen::MatrixXf g(udim, udim);
  float v = sqrtf(powf(z(2, 0), 2) + powf(z(3, 0), 2));

  g(0, 0) = -z(3, 0) * v;
  g(0, 1) = z(2, 0) / v;
  g(1, 0) = z(2, 0) * v;
  g(1, 1) = z(3, 0) / v;

  return g;
}

Eigen::MatrixXf dynamicsClass::getZfromX()
{
  xToZ();
  return z;
}

Eigen::MatrixXf dynamicsClass::getXfromZ()
{
  zToX();
  return x;
}