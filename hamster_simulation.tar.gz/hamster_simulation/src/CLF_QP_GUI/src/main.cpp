/**
 * @file /src/main.cpp
 *
 * @brief Qt based gui.
 *
 * @date November 2010
 **/
/*****************************************************************************
** Includes
*****************************************************************************/

#include <QApplication>
#include <QtGui>
#include "../include/CLF_QP_GUI/main_window.hpp"

/*****************************************************************************
** Main
*****************************************************************************/

int main(int argc, char **argv)
{
  /*********************
  ** Qt
  **********************/
  QApplication app(argc, argv);
  CLF_QP_GUI::MainWindow w(argc, argv);
  w.show();

  return app.exec();
}
