/**
 *  HAMSTER ROS Adaptive Control
 *  dynamicsClass.cpp
 *  Purpose: Class to define the vehicle dynamics of Hamster bot and its various functions
 *
 *  @author Aniketh Manjunath
 *  @version 1.0 - 11 Jan 2020
 */

#include <cmath>
#include <eigen3/Eigen/Dense>

class dynamicsClass
{
  Eigen::MatrixXf x;  // state vector
  Eigen::MatrixXf u;  // control vector
  Eigen::MatrixXf z;  // transformation vector

  // float *x;  // state vector
  // float *u;  // control vector
  // float *z;  // transformation of x

  int xdim = 0;
  int udim = 0;

public:
  dynamicsClass(int xdim, int udim);

  void initX(Eigen::MatrixXf x);

  void initU(Eigen::MatrixXf u);

  void xToZ();

  void zToX();

  Eigen::MatrixXf getF();

  Eigen::MatrixXf getG();

  Eigen::MatrixXf getZfromX();

  Eigen::MatrixXf getXfromZ();
};