
#include <algorithm>
#include <eigen3/Eigen/Dense>

class refModelClass
{
  int xdim = 0;
  int udim = 0;

  float v = 0;
  float dt = 0;
  float radius = 0;

  // Next target position in steps of degrees
  float next_step = 0;

  Eigen::MatrixXf x_rm;  // state vector

public:
  refModelClass(int xdim, int udim, float radius, float v, float next_step, float dt);

  Eigen::MatrixXf get_x_rm(Eigen::MatrixXf my_pos, Eigen::MatrixXf center);

  Eigen::MatrixXf get_mu_rm(Eigen::MatrixXf z_rm);

  float getGradient(Eigen::MatrixXf p1, Eigen::MatrixXf p2);

  void set_radius(float radius);

  void set_speed(float v);
};