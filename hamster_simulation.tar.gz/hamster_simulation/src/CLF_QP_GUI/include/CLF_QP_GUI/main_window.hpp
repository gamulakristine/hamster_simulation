/**
 * @file /include/CLF_QP_GUI/main_window.hpp
 *
 * @brief Qt based gui for CLF_QP_GUI.
 *
 * @date November 2010
 **/
#ifndef CLF_QP_GUI_MAIN_WINDOW_H
#define CLF_QP_GUI_MAIN_WINDOW_H

/*****************************************************************************
** Includes
*****************************************************************************/

#include <QtGui/QMainWindow>
#include "qnode.hpp"
#include "ui_main_window.h"

/*****************************************************************************
** Namespace
*****************************************************************************/

namespace CLF_QP_GUI
{
/*****************************************************************************
** Interface [MainWindow]
*****************************************************************************/
/**
 * @brief Qt central, all operations relating to the view part here.
 */
class MainWindow : public QMainWindow
{
  Q_OBJECT

public:
  MainWindow(int argc, char **argv, QWidget *parent = 0);
  ~MainWindow();

  void closeEvent(QCloseEvent *event);  // Overloaded function

public Q_SLOTS:
  /******************************************
  ** Auto-connections (connectSlotsByName())
  *******************************************/
  void on_pushButtonCommit_clicked();

  void on_pushButtonReset_clicked();

  void on_pushButtonStop_clicked();

private:
  Ui::MainWindow ui;
  QNode qnode;

  bool started = false;
};

}  // namespace CLF_QP_GUI

#endif  // CLF_QP_GUI_MAIN_WINDOW_H
