/**
 * @file /include/CLF_QP_GUI/qnode.hpp
 *
 * @brief Communications central!
 *
 * @date February 2011
 **/
/*****************************************************************************
** Ifdefs
*****************************************************************************/

#ifndef CLF_QP_GUI_QNODE_HPP_
#define CLF_QP_GUI_QNODE_HPP_

/*****************************************************************************
** Includes
*****************************************************************************/

// To workaround boost/qt4 problems that won't be bugfixed. Refer to
//    https://bugreports.qt.io/browse/QTBUG-22829
#ifndef Q_MOC_RUN
#include <ackermann_msgs/AckermannDriveStamped.h>
#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <tf/transform_listener.h>
#include "../include/myCLFSolver.hpp"
#include "../include/myQPSolver.hpp"
#endif
#include <QThread>
#include <cmath>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/QR>
#include <fstream>
#include <string>
#include "../include/PDcontrollerClass.hpp"
#include "../include/dynamicsClass.hpp"
#include "../include/refModelClass.hpp"

/*****************************************************************************
** Namespaces
*****************************************************************************/

namespace CLF_QP_GUI
{
/*****************************************************************************
** Class
*****************************************************************************/

static Eigen::MatrixXf x;
static void odomCallback(const nav_msgs::Odometry::ConstPtr& msg);

class QNode : public QThread
{
  Q_OBJECT
public:
  // PD Model Params
  float kp = 1.;
  float kd = 1.;

  // Ref Model Params
  float v = 0.5;
  float radius = 1.f;

  bool new_commit = true;
  bool PD_control = true;

  QNode(int argc, char** argv);
  virtual ~QNode();
  bool init(bool);
  void run();

private:
  int init_argc;
  char** init_argv;

  // Length of Hamster Robot
  float L = 0.2f;

  int xdim = 4;
  int udim = 2;

  float dt = 0.1;
  float step = 10 * M_PI / 180;

  Eigen::MatrixXf u;
  Eigen::MatrixXf z;
  Eigen::MatrixXf center;

  ackermann_msgs::AckermannDriveStamped steering;

  // Subscribe to Odometer readings
  ros::Subscriber odom_sub;

  // Publish to ackermann_cmd for robot motion control
  ros::Publisher ackr_pub;
};

}  // namespace CLF_QP_GUI

#endif /* CLF_QP_GUI_QNODE_HPP_ */