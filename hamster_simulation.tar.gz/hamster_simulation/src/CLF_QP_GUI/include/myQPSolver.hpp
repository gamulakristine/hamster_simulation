#include <osqp/osqp.h>
#include <algorithm>
#include "ros/ros.h"

class myQPSolver
{
  // Load problem data

  // P -> Identity matrix of size 2
  c_float P_x[2] = {
    1.0, 1.0,
  };

  c_int P_nnz = 2;

  c_int P_i[2] = {
    0, 1,
  };

  c_int P_p[3] = {
    0, 1, 2,
  };

  // q -> mu_pd
  c_float q[2] = {
    0, 0,
  };

  // A -> Identity matrix of size 2
  c_float A_x[2] = {
    1.0, 1.0,
  };

  c_int A_nnz = 2;

  c_int A_i[2] = {
    0, 1,
  };

  c_int A_p[3] = {
    0, 1, 2,
  };

  c_float l[2] = {
    -INFINITY, -INFINITY,
  };

  c_float u[2] = {
    INFINITY, INFINITY,
  };

  c_int n = 2;
  c_int m = 2;

  // Exitflag
  c_int exitflag = 0;

  // Workspace structures
  OSQPWorkspace *work;
  OSQPSettings *settings = (OSQPSettings *)c_malloc(sizeof(OSQPSettings));
  OSQPData *data = (OSQPData *)c_malloc(sizeof(OSQPData));

public:
  myQPSolver();
  void solve(float *);
  ~myQPSolver();
};